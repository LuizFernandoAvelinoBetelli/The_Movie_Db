package com.example.f290_dsm_aula_05_abril_24

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
